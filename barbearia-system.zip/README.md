# Barbearia System

Projeto Maven completo para gerenciamento de barbearia.